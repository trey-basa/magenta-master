//  Copyright (c) 2015 Doe Pics Hit, Inc. All rights reserved.

#import <Foundation/Foundation.h>
#import <UIKit/UIApplication.h>

@interface BuddyBuildSDK : NSObject
+ (void)setup:(id<UIApplicationDelegate>)bbAppDelegate;
+ (void)setup;
@end
