'use strict';

module.exports = {

	FACEBOOK_APP_ID: 1435210983455180,

	GOOGLE_API_KEY: "AIzaSyA_ZvkfZiWe1uJlRbuXpWsSqYGV523Vvps"

};