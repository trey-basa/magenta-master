/* global jest */

// Sometimes Travis is very slow...
jest.setTimeout(30000);
