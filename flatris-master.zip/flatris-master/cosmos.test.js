import runTelescope from 'react-cosmos-telescope';

runTelescope();
