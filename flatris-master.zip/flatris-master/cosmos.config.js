module.exports = {
  globalImports: ['./global.css'],
  publicPath: 'static',
  publicUrl: '/static/'
};
