import Logo from '../../Logo';

export default {
  component: Logo,
  props: {}
};
