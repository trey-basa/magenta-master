import Loading from '../../Loading';

export default {
  component: Loading
};
