// @flow

import { createFixture } from '../../../utils/create-fixture';
import GamePreviewShell from '../../GamePreviewShell';

export default createFixture({
  component: GamePreviewShell,

  props: {},

  container: {}
});
