// @flow

import Left from '../../Left';

export default {
  component: Left,
  props: {
    onPress: () => console.log('Pressing...')
  }
};
